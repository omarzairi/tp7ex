export class Employe {
    constructor(
        public matricule:number,
        public nom:string,
        public fonction:string,
        public departement:string){

        }
}
